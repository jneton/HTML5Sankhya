const m=new Map([['4',{manager:'4'}],['12',{manager:'23'}],['10',{manager:'12'}],['20',{manager:'12'}],['23',{manager:'23'}],['77',{manager:'12'}]]);
const V6_CODIGOS_GERENTES=new Set([...m.values()].map(x=>String(x.manager)).filter(id=>id!=='-1'));
function v6GerenciaRepresentante(rep,meta){ const id=String(rep); return V6_CODIGOS_GERENTES.has(id)?id:String(meta.manager||'-1'); }
const rows=[['4',5],['12',8],['10',3],['20',7],['23',11],['77',0]];const groups=new Map();
for(const [rep,n] of rows){let ger=v6GerenciaRepresentante(rep,m.get(rep)); if(!groups.has(ger))groups.set(ger,[]);groups.get(ger).push([rep,n]);}
if(!groups.has('4') || groups.get('4').length!==1)throw Error('manager 4');
if(!groups.get('12').some(x=>x[0]==='12'))throw Error('manager 12 missing');
if(groups.get('23').some(x=>x[0]==='12'))throw Error('manager double count');
const total=[...groups.values()].flat().reduce((s,r)=>s+r[1],0);
if(total!==34||[...groups.values()].flat().length!==rows.length)throw Error('duplicate revenue');
console.log(JSON.stringify(Object.fromEntries(groups)));
