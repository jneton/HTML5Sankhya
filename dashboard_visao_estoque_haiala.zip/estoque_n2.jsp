<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html><head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/estoque.css">
<snk:load/>
<script type="text/javascript">
function selecionar(codigo) {
  refreshDetails('html5_est_n3', {GRUPOPAI: codigo});
  refreshDetails('html5_est_n4', {GRUPOPAI: -1});
  refreshDetails('html5_est_produtos', {GRUPO: -1});
}
</script>
</head><body>
<div class="painel">
  <div class="titulo">Nível 02</div>
  <div class="grade-wrap">
    <snk:query var="dados"><![CDATA[
WITH hierarquia AS (
    SELECT DISTINCT g1.codgrupoprod grupo_n1, g2.codgrupoprod grupo_n2,
           g3.codgrupoprod grupo_n3, g4.codgrupoprod grupo_n4
      FROM tgfgru g1
      JOIN tgfgru g2 ON g2.codgrupai = g1.codgrupoprod AND g2.grau = 2
      LEFT JOIN tgfgru g3 ON g3.codgrupai = g2.codgrupoprod AND g3.grau = 3
      LEFT JOIN tgfgru g4 ON g4.codgrupai = g3.codgrupoprod AND g4.grau = 4
     WHERE g1.grau = 1 AND g2.codgrupai = :GRUPOPAI
),
estoque AS (SELECT codprod, SUM(NVL(estoque,0)) estoqueatual FROM tgfest GROUP BY codprod),
produtos AS (
    SELECT codprod,codgrupoprod,NVL(estmax,0) estmax
      FROM tgfpro WHERE (ativo = :P_ATIVO OR :P_ATIVO = 'T')
),
base AS (
    SELECT h.grupo_n2,p.codprod,p.estmax,NVL(e.estoqueatual,0) estoqueatual
      FROM hierarquia h JOIN produtos p
        ON p.codgrupoprod = NVL(h.grupo_n4,NVL(h.grupo_n3,h.grupo_n2))
      LEFT JOIN estoque e ON e.codprod=p.codprod
)
SELECT g.codgrupoprod grupo_n2,g.descrgrupoprod descr_n2,
       SUM(b.estmax) estmax,SUM(b.estoqueatual) estoqueatual,
       NVL(ROUND(SUM(b.estoqueatual)/NULLIF(SUM(b.estmax),0),4),0)*100 pct
  FROM tgfgru g LEFT JOIN base b ON b.grupo_n2=g.codgrupoprod
 WHERE g.grau=2 AND g.codgrupai=:GRUPOPAI AND g.ativo='S'
 GROUP BY g.codgrupoprod,g.descrgrupoprod ORDER BY g.codgrupoprod
    ]]></snk:query>
    <table>
      <thead><tr><th>Descrição</th><th class="numero">Est. Máx.</th><th class="numero">Est. Atual</th><th class="numero">%</th></tr></thead>
      <tbody>
        <c:forEach items="${dados.rows}" var="row">
          <tr class="selecionavel" onclick="selecionar(${row.GRUPO_N2})">
            <td><button class="selecao" type="button" onclick="event.stopPropagation(); selecionar(${row.GRUPO_N2});"><c:out value="${row.DESCR_N2}"/></button></td>
            <td class="numero"><c:out value="${row.ESTMAX}"/></td>
            <td class="numero"><c:out value="${row.ESTOQUEATUAL}"/></td>
            <td class="percentual"><c:out value="${row.PCT}"/>%</td>
          </tr>
        </c:forEach>
        <c:if test="${empty dados.rows}"><tr><td colspan="4" class="vazio">Selecione um grupo no nível anterior.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div>
</body></html>
