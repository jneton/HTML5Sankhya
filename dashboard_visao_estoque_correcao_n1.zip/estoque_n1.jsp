<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html><head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/estoque.css">
<snk:load/>
<script type="text/javascript">
function selecionar(codigo) {
  refreshDetails('html5_est_n2', {GRUPOPAI: codigo});
  refreshDetails('html5_est_n3', {GRUPOPAI: -1});
  refreshDetails('html5_est_n4', {GRUPOPAI: -1});
  refreshDetails('html5_est_produtos', {GRUPO: -1});
}
</script>
</head><body>
<div class="painel">
  <div class="titulo">Nível 01</div>
  <div class="grade-wrap">
    <snk:query var="dados">
WITH
/* ============================================================
   1. Grupos de primeiro nível que serão apresentados no painel
   ============================================================ */
grupos_exibicao AS (
    SELECT g.codgrupoprod AS codgrupo,
           g.descrgrupoprod AS descricao
      FROM tgfgru g
     WHERE g.grau = 1
       AND g.ativo = 'S'
       AND TO_NUMBER(SUBSTR(TO_CHAR(g.codgrupoprod, 'FM000000000'), 1, 2)) <= 7
),

/* ============================================================
   2. Hierarquia: inicia diretamente nos grupos de nível 1.
      Não utiliza subconsulta no START WITH.
      Cada grupo descendente fica associado ao seu grupo raiz.
   ============================================================ */
grupos_descendentes AS (
    SELECT CONNECT_BY_ROOT g.codgrupoprod AS grupo_exibicao,
           g.codgrupoprod                AS grupo_produto
      FROM tgfgru g
     START WITH g.grau = 1
        AND g.ativo = 'S'
        AND TO_NUMBER(SUBSTR(TO_CHAR(g.codgrupoprod, 'FM000000000'), 1, 2)) <= 7
   CONNECT BY NOCYCLE PRIOR g.codgrupoprod = g.codgrupai
),

/* ============================================================
   3. Produtos conforme o filtro do dashboard:
      A = ativos | I = inativos | T = todos
   ============================================================ */
produtos_filtrados AS (
    SELECT p.codprod,
           p.codgrupoprod,
           NVL(p.estmax, 0) AS estmax
      FROM tgfpro p
     WHERE UPPER(NVL(:P_ATIVO, 'T')) = 'T'
        OR (UPPER(:P_ATIVO) = 'A' AND p.ativo = 'S')
        OR (UPPER(:P_ATIVO) = 'I' AND p.ativo = 'N')
),

/* ============================================================
   4. Estoque consolidado por produto
   ============================================================ */
estoque AS (
    SELECT e.codprod,
           SUM(NVL(e.estoque, 0)) AS estoqueatual
      FROM tgfest e
     GROUP BY e.codprod
),

/* ============================================================
   5. Totalização por grupo de nível 1.
      Considera produtos vinculados diretamente ao grupo raiz
      ou a qualquer subgrupo abaixo dele.
   ============================================================ */
totais AS (
    SELECT d.grupo_exibicao,
           SUM(p.estmax) AS estmax,
           SUM(NVL(e.estoqueatual, 0)) AS estoqueatual
      FROM grupos_descendentes d
      JOIN produtos_filtrados p
        ON p.codgrupoprod = d.grupo_produto
      LEFT JOIN estoque e
        ON e.codprod = p.codprod
     GROUP BY d.grupo_exibicao
)

/* ============================================================
   6. Resultado final do Nível 1
   ============================================================ */
SELECT g.codgrupo,
       g.descricao,
       NVL(t.estmax, 0) AS estmax,
       NVL(t.estoqueatual, 0) AS estoqueatual,
       NVL(ROUND(t.estoqueatual / NULLIF(t.estmax, 0) * 100, 2), 0) AS pct
  FROM grupos_exibicao g
  LEFT JOIN totais t
    ON t.grupo_exibicao = g.codgrupo
 ORDER BY g.codgrupo
    </snk:query>
    <table>
      <thead><tr><th>Descrição</th><th class="numero">Est. Máx.</th><th class="numero">Est. Atual</th><th class="numero">%</th></tr></thead>
      <tbody>
        <c:forEach items="${dados.rows}" var="row">
          <tr class="selecionavel" onclick="selecionar(${row.CODGRUPO})">
            <td><button class="selecao" type="button" onclick="event.stopPropagation(); selecionar(${row.CODGRUPO});"><c:out value="${row.DESCRICAO}"/></button></td>
            <td class="numero"><c:out value="${row.ESTMAX}"/></td>
            <td class="numero"><c:out value="${row.ESTOQUEATUAL}"/></td>
            <td class="percentual"><c:out value="${row.PCT}"/>%</td>
          </tr>
        </c:forEach>
        <c:if test="${empty dados.rows}"><tr><td colspan="4" class="vazio">Nenhum grupo encontrado para os filtros selecionados.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div>
</body></html>
