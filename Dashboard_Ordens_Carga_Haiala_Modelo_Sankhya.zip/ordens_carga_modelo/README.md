# Dashboard de Ordens de Carga - Haiala | modelo Sankhya executeQuery

## Alterações
- JSP reescrito com o padrão do arquivo `JSP_MODELO.jsp` enviado.
- Execução SQL por `executeQuery(query, parametros, onSuccess, onError)`.
- Parâmetro multilista `P_OC` com `type: "IN"` e cláusula `IN (?)`, conforme o exemplo oficial fornecido.
- Parâmetro `SIT` enviado duas vezes como texto (`type: "S"`), correspondendo aos dois placeholders SQL.
- Indicadores e grade montados no callback de sucesso; pesquisa da tabela no navegador.
- CSS e XML de parâmetros preservados.

## Publicação
1. Faça backup do componente atual.
2. Publique `dashboard.jsp` e a pasta `css` no caminho do componente.
3. Mantenha o XML e confirme que o gadget aponta para `dashboard.jsp`.
4. Teste com poucas OCs e compare os resultados com a consulta original.

## Observações para homologação
- A consulta mantém a chamada `OPTION_LABEL`; se o callback retornar erro relacionado a essa função, isole-a temporariamente substituindo `SET_SA` por `CAST(NULL AS VARCHAR2(200))`.
- `LISTAGG` permanece sujeito ao limite de tamanho e pode gerar ORA-01489 em listas extensas.
- A consulta e o JSP foram reestruturados estaticamente; a execução final depende da validação no ambiente Sankhya/Oracle da empresa.
- Se o parâmetro multilista retornar erro, verificar o valor efetivo de `${P_OC}` e o comportamento do tipo `IN` no ambiente, mantendo o padrão demonstrado no modelo fornecido.
