

<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8"  isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
<snk:load/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulação de Custos de Produtos - Dashboard</title>
    <style>
        :root {
            --primary-color: #1e293b;
            --secondary-color: #f1f5f9;
            --accent-color: #16a34a;
            --border-color: #cbd5e1;
            --header-bg: #e2e8f0;
            --hover-bg: #f8fafc;
            --text-color: #0f172a;
            --card-bg: #ffffff;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        html, body {
            height: 100vh;
            background-color: var(--secondary-color);
            color: var(--text-color);
            overflow: hidden; /* Evita rolagem na página inteira, mantendo focado no painel */
        }

        /* Container Principal Occupando 100% da tela */
        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            padding: 12px;
            gap: 12px;
        }

        /* Título e Header Compacto */
        .page-title {
            font-size: 1.1rem;
            color: var(--primary-color);
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Seção de Detalhes do Produto */
        .product-header {
            background-color: var(--card-bg);
            padding: 10px 15px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 8px 15px;
            font-size: 0.82rem;
        }

        .header-item strong {
            color: var(--primary-color);
        }

        .badge {
            display: inline-block;
            padding: 1px 6px;
            font-size: 0.75rem;
            font-weight: bold;
            color: #fff;
            background-color: var(--accent-color);
            border-radius: 3px;
        }

        /* Grid Principal com 4 colunas que ocupam a altura restante */
        .table-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            flex: 1; /* Preenche todo o espaço vertical disponível */
            min-height: 0; /* Permite que o flexbox encolha e ative o scroll */
        }

        /* Card da Tabela */
        .table-card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            height: 100%;
            min-height: 0; /* Necessário para scroll interno funcionar */
        }

        /* Cabeçalho de cada Tabela */
        .card-header {
            background-color: var(--primary-color);
            color: #fff;
            padding: 8px 12px;
            font-weight: 600;
            font-size: 0.85rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
        }

        .item-count {
            background-color: rgba(255, 255, 255, 0.2);
            padding: 2px 6px;
            border-radius: 10px;
            font-size: 0.75rem;
        }

        /* Área com Rolagem (Scrollbar) da Tabela */
        .table-wrapper {
            flex: 1;
            overflow-y: auto; /* Barra de rolagem vertical ativada */
            overflow-x: auto; /* Barra de rolagem horizontal se a tela for estreita */
        }

        /* Estilização da Barra de Rolagem */
        .table-wrapper::-webkit-scrollbar {
            width: 7px;
            height: 7px;
        }

        .table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        .table-wrapper::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }

        .table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

        /* Tabela */
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            text-align: left;
        }

        th {
            position: sticky; /* Mantém o cabeçalho visível durante o scroll */
            top: 0;
            background-color: var(--header-bg);
            color: var(--primary-color);
            font-weight: 600;
            padding: 8px;
            border-bottom: 1px solid var(--border-color);
            white-space: nowrap;
            z-index: 10;
        }

        td {
            padding: 6px 8px;
            border-bottom: 1px solid #f1f5f9;
            white-space: nowrap;
        }

        tbody tr:hover {
            background-color: var(--hover-bg);
        }

        .num-col {
            text-align: right;
        }

        /* Rodapé Fixo da Tabela com Total */
        .table-footer {
            background-color: #f8fafc;
            padding: 8px 12px;
            border-top: 1px solid var(--border-color);
            font-weight: bold;
            font-size: 0.82rem;
            display: flex;
            justify-content: space-between;
            color: var(--primary-color);
        }

        /* Responsividade para Telas Menores */
        @media (max-width: 1200px) {
            html, body {
                overflow: auto; /* Reativa scroll geral apenas em telas menores */
                height: auto;
            }
            .app-container {
                height: auto;
            }
            .table-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .table-card {
                height: 400px; /* Altura fixa quando empilhado em tablets */
            }
        }

        @media (max-width: 768px) {
            .table-grid {
                grid-template-columns: 1fr;
            }
            .table-card {
                height: 350px; /* Altura fixa para smartphones */
            }
        }
    </style>
</head>
<body>

<snk:query var="cabecalho">
SELECT pro.codprod AS codprod,
       pro.referencia AS codvendas,
       (pro.descrprod || pro.compldesc) AS descricao_produto,
       TO_CHAR(TRUNC(:P_XDT), 'DD/MM/YYYY') AS data_base,
       pro.pesobruto,
       upper(option_label('TGFPRO', 'AD_TP_ESTOQUE', pro.ad_tp_estoque)) AS tipo_estoque,
       CASE pro.ativo           WHEN 'S' THEN 'SIM' ELSE 'NÃO' END AS ativo,
       CASE pro.ad_palm         WHEN 'S' THEN 'SIM' ELSE 'NÃO' END AS utiliza_ladix,
       CASE pro.ad_permitevenda WHEN 'S' THEN 'SIM' ELSE 'NÃO' END AS permite_venda,
       upper(CASE :P_TP         WHEN '0' THEN 'Custo Com ICMS'
                                WHEN '1' THEN 'Custo Sem ICMS'
                                WHEN '2' THEN 'Custo Reposição'
                                WHEN '3' THEN 'Custo Variável'
                                WHEN '4' THEN 'Custo Gerencial'
                                WHEN '5' THEN 'Custo Médio'
                                WHEN '6' THEN 'Valor Objetivo'
                                ELSE 'Tipo de Custo Inválido'
             END) AS tipo_custo
  FROM tgfpro pro
 WHERE pro.codprod = :P_CODPROD

</snk:query>

    <div class="app-container">
        <!-- Detalhes do Produto -->
        <div class="product-header">
            <c:forEach items="${cabecalho.rows}" var="row">
                <div class="header-item"><strong>Cód. Indústria: </strong><c:out value="${row.codprod}" /></div>
                <div class="header-item"><strong>Cód. Venda: </strong><c:out value="${row.codvendas}" /></div>
                <div class="header-item"><strong>Peso Bruto: </strong><c:out value="${row.pesobruto}" /> kg</div>
                <div class="header-item"><strong>Tipo de Custo: </strong><c:out value="${row.tipo_custo}" /></div>
                <div class="header-item"><strong>Data Base: </strong><c:out value="${row.data_base}" /></div>
                <div class="header-item" style="grid-column: span 2;">
                    <strong>Descrição: </strong> <c:out value="${row.descricao_produto}" />
                </div>
                <div class="header-item">
                    <strong>Ativo: </strong> <span class="badge"><c:out value="${row.ativo}" /></span>
                </div>
            </c:forEach>
        </div>

        <!-- Grid das 4 Tabelas Lado a Lado -->
        <div class="table-grid">

            <!-- Tabela Nível 1 -->
            <div class="table-card">
                <div class="card-header">
                    <span>Nível 1</span>
                    <span class="item-count">18 itens</span>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th class="num-col">Qtd</th>
                                <th class="num-col">Custo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>468</td><td>CANTONEIRA ( M2-120 EXTRA )</td><td class="num-col">4,0000</td><td class="num-col">1,9600</td></tr>
                            <tr><td>470</td><td>CANTONEIRA 2150X205 12CM</td><td class="num-col">2,0000</td><td class="num-col">2,9000</td></tr>
                            <tr><td>473</td><td>FITA PLASTICA SOLDAVEL 10 MM</td><td class="num-col">7,8800</td><td class="num-col">0,7092</td></tr>
                            <tr><td>490</td><td>REBITE REPUXO 4.0 X 12 AÇO/ALUMINIO</td><td class="num-col">6,0000</td><td class="num-col">0,3000</td></tr>
                            <tr><td>502</td><td>MACANETA RETA PALI</td><td class="num-col">1,0000</td><td class="num-col">5,5900</td></tr>
                            <tr><td>529</td><td>ESPACADOR DE BATENTE</td><td class="num-col">1,0000</td><td class="num-col">0,2000</td></tr>
                            <tr><td>533</td><td>ABRACADEIRA T50R HELLERMANN</td><td class="num-col">1,0000</td><td class="num-col">0,1400</td></tr>
                            <tr><td>1603</td><td>MECANISMO PARA CILINDRO</td><td class="num-col">1,0000</td><td class="num-col">5,8300</td></tr>
                            <tr><td>1604</td><td>ESPELHO PARA PORTA EXTRA</td><td class="num-col">1,0000</td><td class="num-col">1,4900</td></tr>
                            <tr><td>1675</td><td>MANUAL DO PRODUTO APD / TRAD PRONTA</td><td class="num-col">1,0000</td><td class="num-col">0,3300</td></tr>
                            <tr><td>2919</td><td>SACO PLASTICO 15X20CM</td><td class="num-col">1,0000</td><td class="num-col">0,0500</td></tr>
                            <tr><td>3065</td><td>ETIQUETA ADESIVA LINHA APD</td><td class="num-col">1,0000</td><td class="num-col">0,3100</td></tr>
                            <tr><td>3066</td><td>ETIQUETA DE CERTIFICAÇÃO AÇO</td><td class="num-col">1,0000</td><td class="num-col">0,0800</td></tr>
                            <tr><td>4223</td><td>PINT P ORION APD BRANCA 085X215</td><td class="num-col">1,0000</td><td class="num-col">101,5253</td></tr>
                            <tr><td>4254</td><td>FITA DUPLA FACE 12 MM x 30M</td><td class="num-col">12,0000</td><td class="num-col">2,0400</td></tr>
                            <tr><td>4693</td><td>BOBINA FOLHA DE PEBD 86CM X 0,06</td><td class="num-col">4,3000</td><td class="num-col">4,3860</td></tr>
                            <tr><td>4851</td><td>ETIQUETA AÇO GALVANIZADO</td><td class="num-col">1,0000</td><td class="num-col">0,0800</td></tr>
                            <tr><td>5599</td><td>BLOCO DE CILINDRO 53MM</td><td class="num-col">1,0000</td><td class="num-col">8,2900</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-footer">
                    <span>Total:</span>
                    <span>R$ 136,2105</span>
                </div>
            </div>

            <!-- Tabela Nível 2 -->
            <div class="table-card">
                <div class="card-header">
                    <span>Nível 2</span>
                    <span class="item-count">4 itens</span>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th class="num-col">Qtd</th>
                                <th class="num-col">Custo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>1012</td><td>GLP A GRANEL</td><td class="num-col">1,0913</td><td class="num-col">5,4344</td></tr>
                            <tr><td>3833</td><td>HIPHOS T 173 ( 4º ESTAGIO )</td><td class="num-col">0,0925</td><td class="num-col">2,0567</td></tr>
                            <tr><td>4032</td><td>SA P ORION APD 085X215 DIR REQ12</td><td class="num-col">1,0000</td><td class="num-col">78,8224</td></tr>
                            <tr><td>4403</td><td>TINTA BRANCO LA 5088 INTERPON</td><td class="num-col">0,7710</td><td class="num-col">15,2118</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-footer">
                    <span>Total:</span>
                    <span>R$ 101,5253</span>
                </div>
            </div>

            <!-- Tabela Nível 3 -->
            <div class="table-card">
                <div class="card-header">
                    <span>Nível 3</span>
                    <span class="item-count">16 itens</span>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th class="num-col">Qtd</th>
                                <th class="num-col">Custo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>464</td><td>DOBRADICA CARREGACAO 3 "</td><td class="num-col">3,0000</td><td class="num-col">1,9200</td></tr>
                            <tr><td>500</td><td>CONTRA TESTA</td><td class="num-col">1,0000</td><td class="num-col">0,3800</td></tr>
                            <tr><td>598</td><td>PORTAL DOB 2150X200 #26 ( P.S.REQ12 )</td><td class="num-col">1,0000</td><td class="num-col">8,1700</td></tr>
                            <tr><td>599</td><td>PORTAL DIR 2150X200 #26 ( P.S.REQ12 )</td><td class="num-col">1,0000</td><td class="num-col">8,1700</td></tr>
                            <tr><td>622</td><td>PORTAL TRAV 810X200 #26 ( P.S.REQ12 )</td><td class="num-col">1,0000</td><td class="num-col">3,0780</td></tr>
                            <tr><td>647</td><td>CAD EST 2085X229 #26</td><td class="num-col">1,0000</td><td class="num-col">9,0725</td></tr>
                            <tr><td>648</td><td>CAD DOB 2085X229 #26</td><td class="num-col">1,0000</td><td class="num-col">9,0725</td></tr>
                            <tr><td>671</td><td>CAD TRAV FECHADA 790X229 #26</td><td class="num-col">2,0000</td><td class="num-col">6,8400</td></tr>
                            <tr><td>725</td><td>PERFIL U TRAVAMENTO 780X35 #24</td><td class="num-col">1,0000</td><td class="num-col">0,5975</td></tr>
                            <tr><td>726</td><td>PERFIL U TRAVAMENTO 810X35 #24</td><td class="num-col">1,0000</td><td class="num-col">0,6205</td></tr>
                            <tr><td>799</td><td>COXINHO 193X56 #26</td><td class="num-col">1,0000</td><td class="num-col">0,2304</td></tr>
                            <tr><td>804</td><td>CHAPA TRAVAMENTO 118X38 #24</td><td class="num-col">1,0000</td><td class="num-col">0,0920</td></tr>
                            <tr><td>836</td><td>SUPORTE PORTA 110X130 #24</td><td class="num-col">1,0000</td><td class="num-col">0,3156</td></tr>
                            <tr><td>913</td><td>PALHETA CANELADA 2275X670 #26</td><td class="num-col">1,0000</td><td class="num-col">29,4657</td></tr>
                            <tr><td>1590</td><td>PERFIL U TRAVAMENTO 118X35 #24</td><td class="num-col">5,0000</td><td class="num-col">0,4347</td></tr>
                            <tr><td>2641</td><td>PERFIL ZEE DA ALÇA 117X47 #24</td><td class="num-col">3,0000</td><td class="num-col">0,3629</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-footer">
                    <span>Total:</span>
                    <span>R$ 78,8224</span>
                </div>
            </div>

            <!-- Tabela Nível 4 -->
            <div class="table-card">
                <div class="card-header">
                    <span>Nível 4</span>
                    <span class="item-count">1 item</span>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th class="num-col">Qtd</th>
                                <th class="num-col">Custo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>1438</td><td>CHAPA ELETROGAL 0,60X35 ( #24 )</td><td class="num-col">0,1349</td><td class="num-col">0,6205</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-footer">
                    <span>Total:</span>
                    <span>R$ 0,6205</span>
                </div>
            </div>

        </div>
    </div>

</body>
</html>