# Dashboard Visão do Estoque – Haiala

## Conteúdo
- `model_XML_Oracle.xml`: definição do gadget, prompt e composição dos componentes.
- `estoque_n1.jsp` a `estoque_n4.jsp`: quatro níveis de agrupamento.
- `estoque_produtos.jsp`: grade de produtos e valores mensais.
- `css/estoque.css`: layout responsivo e estilos.

## Instalação
1. Importe o XML pelo mecanismo de publicação de gadgets/componentes HTML5 do Sankhya.
2. Publique os JSPs e a pasta `css` na mesma pasta-base do componente, respeitando os `entryPoint` do XML.
3. Valide o parâmetro `P_ATIVO` e os argumentos `GRUPOPAI` e `GRUPO` no ambiente.
4. Execute primeiro cada consulta isoladamente no Oracle 19c com os mesmos parâmetros.
5. Teste a navegação: Nível 01 -> Nível 02 -> Nível 03 -> Nível 04 -> Produtos.
6. A atualização da grade de produtos foi retirada dos cliques dos níveis 01, 02 e 03. Ela é solicitada somente pelo Nível 04, evitando a chamada prematura ao detalhe `html5_est_produtos` que gerava CORE_E05294 ao clicar no Nível 01.

## Observações técnicas importantes
- O modelo original usa `snk:load`, `snk:query`, JSTL, `refreshDetails` e `html5component`; a implementação segue esse padrão, sem criar endpoints ou classes Java.
- O prompt `P_ATIVO` usa `A` (ativos), `I` (inativos) e `T` (todos). Como o campo `TGFPRO.ATIVO` utiliza `S` para ativo e `N` para inativo no Sankhya, as consultas fazem a conversão: `A` -> `S`, `I` -> `N`; `T` não restringe a situação.
- Os níveis inferiores iniciam sem dados até que um grupo do nível anterior seja selecionado.
- As consultas dos níveis 1 a 3 somam produtos atribuídos diretamente ao grupo ou a qualquer subnível (até o nível 4), sem duplicar os totais. O filtro arbitrário por prefixo numérico do código de grupo foi removido do nível 1.
- A grade mensal mantém a chamada `FC_CUSTOEST_HAI5` para os doze fechamentos do ano. Como a função é executada por produto/mês, o custo de execução pode ser elevado para muitos produtos.
- Os valores mensais são apresentados como **Custo Jan, Custo Fev...**, pois a consulta utiliza `FC_CUSTOEST_HAI5`; confirme se essa função retorna custo/valor ou quantidade no contexto da Haiala antes de alterar o rótulo.
- A consulta de centro de trabalho mantém a regra original de escolher um único centro por produto (`ROW_NUMBER` ordenado por `CODWCP`).
- A implementação foi montada a partir do modelo fornecido, mas não foi possível executar no servidor Sankhya nem validar permissões, publicação, versão de JSTL ou compilação das consultas no banco. É necessário homologar no ambiente TESTE antes da publicação em produção.

## Ponto para homologação
Confirmar se `P_ATIVO` chega como parâmetro global para todos os HTML5 Components e se o Sankhya permite o `refreshDetails` entre componentes irmãos no mesmo nível. O exemplo do ZIP demonstra `refreshDetails` para outro componente; a navegação deste dashboard depende desse comportamento.
