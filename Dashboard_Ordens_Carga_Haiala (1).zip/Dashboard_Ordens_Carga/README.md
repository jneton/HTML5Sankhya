# Dashboard de Ordens de Carga - Haiala

## Arquivos
- `model_XML_Oracle.xml`: gadget, parâmetros P_OC e SIT e componente HTML5.
- `dashboard.jsp`: consulta via `snk:query`, indicadores e grade de produtos.
- `css/dashboardCSS.css`: layout responsivo.
- `sql/consulta_ordens_carga.sql`: versão SQL separada para revisão e execução no Oracle.

## Instalação
1. Faça uma cópia de segurança do componente atual.
2. Cadastre/importar o XML no Construtor de Dashboards conforme o procedimento usado no ambiente.
3. Publique `dashboard.jsp` e a pasta `css` no diretório de arquivos do componente, mantendo a estrutura relativa.
4. Confirme que os parâmetros `P_OC` e `SIT` aparecem no prompt e teste com poucas ordens.
5. Compare os totais com a consulta original antes de liberar aos usuários.

## Atenção antes de produção
- O XML define `SIT` como valores `N` e `S`. Confirme se `TGFORD.AD_FORMCONC` utiliza exatamente esses códigos no ambiente.
- O componente foi construído a partir do exemplo enviado, mas não foi possível executar no ambiente Sankhya/Oracle da empresa.
- A consulta foi reorganizada para consolidar por produto e evitar o relacionamento incorreto das observações apenas por produto com múltiplas linhas por ordem.
- O texto de ordens de carga é uma lista compacta por produto; não reproduz as 30 colunas fixas do PIVOT original.
- A soma de `M3_PROD * PENDENTE` considera `TGFPRO.M3` como volume unitário, conforme a consulta fornecida.
- Valide os nomes e tipos de `AD_COD_PROD_SA`, `AD_SET_PRODUCAO`, `AD_FORMCONC`, `AD_VLRLIQ` e `AD_VLRUNITFRETE` no dicionário da sua base.
- Se `LISTAGG` ultrapassar o limite de 4.000 bytes, a coluna de pedidos observados ou ordens poderá gerar ORA-01489; nesse caso, limitar a lista ou usar XMLAGG/CLOB.

## Correção de parâmetros multilista
- Os filtros multilista foram ajustados para a sintaxe `IN :P_OC` e `IN :SIT`, seguindo o padrão da consulta original fornecida para o ambiente Sankhya.
- O filtro `AD_FORMCONC` também é aplicado na CTE `ordens_filtradas` antes da consolidação dos itens.
