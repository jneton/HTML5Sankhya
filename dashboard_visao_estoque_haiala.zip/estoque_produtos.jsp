<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html><head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/estoque.css">
<snk:load/>
</head><body>
<div class="painel produtos">
  <div class="titulo">Produto(s) — Estoque e acompanhamento mensal</div>
  <div class="subtitulo">Os valores mensais representam o custo calculado pela FC_CUSTOEST_HAI5, conforme a consulta fornecida.</div>
  <div class="grade-wrap">
    <snk:query var="produtos"><![CDATA[
WITH hierarquia AS (
    SELECT DISTINCT g1.codgrupoprod grupo_n1,g1.descrgrupoprod descr_n1,
           g2.codgrupoprod grupo_n2,g2.descrgrupoprod descr_n2,
           g3.codgrupoprod grupo_n3,g3.descrgrupoprod descr_n3,
           g4.codgrupoprod grupo_n4,g4.descrgrupoprod descr_n4
      FROM tgfgru g1
      LEFT JOIN tgfgru g2 ON g2.codgrupai=g1.codgrupoprod AND g2.grau=2
      LEFT JOIN tgfgru g3 ON g3.codgrupai=g2.codgrupoprod AND g3.grau=3
      LEFT JOIN tgfgru g4 ON g4.codgrupai=g3.codgrupoprod AND g4.grau=4
     WHERE g1.grau=1
),
estoque AS (
    SELECT codprod,SUM(NVL(estoque,0)) estoqueatual FROM tgfest GROUP BY codprod
),
centro_trabalho AS (
    SELECT codprod,codwcp,nome FROM (
        SELECT wxb.codprodpa codprod,wcp.codwcp,wcp.nome,
               ROW_NUMBER() OVER(PARTITION BY wxb.codprodpa ORDER BY wcp.codwcp) rn
          FROM tprwxp wxp JOIN tprwcp wcp ON wcp.codwcp=wxp.codwcp
    ) WHERE rn=1
),
base AS (
    SELECT h.*,pr.codprod,pr.descrprod,pr.ativo,
           NVL(pr.estmin,0) estmin,NVL(pr.estmax,0) estmax,
           ct.codwcp,ct.nome,
           OPTION_LABEL('TGFPRO','AD_MAQ_PRODUCAO',NVL(pr.ad_maq_producao,0)) maq_producao,
           NVL(e.estoqueatual,0) estoqueatual
      FROM hierarquia h
      JOIN tgfpro pr ON pr.codgrupoprod=NVL(h.grupo_n4,NVL(h.grupo_n3,NVL(h.grupo_n2,h.grupo_n1)))
      LEFT JOIN centro_trabalho ct ON ct.codprod=pr.codprod
      LEFT JOIN estoque e ON e.codprod=pr.codprod
     WHERE (pr.ativo=:P_ATIVO OR :P_ATIVO='T')
       AND pr.codgrupoprod=:GRUPO
),
custos AS (
    SELECT b.*,
       CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),0)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),0)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS JAN_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),1)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),1)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS FEV_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),2)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),2)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS MAR_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),3)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),3)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS ABR_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),4)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),4)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS MAI_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),5)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),5)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS JUN_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),6)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),6)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS JUL_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),7)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),7)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS AGO_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),8)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),8)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS SET_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),9)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),9)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS OUT_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),10)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),10)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS NOV_PROD, CASE WHEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),11)) <= LAST_DAY(SYSDATE)
         THEN fc_custoest_hai5(1, b.codprod, LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'YYYY'),11)), 'E', NULL, NULL, 'P')
         ELSE 0 END AS DEZ_PROD
      FROM base b
),
resultado AS (
    SELECT c.*,
       ROUND(NVL(JAN_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS JAN_PERC,
       ROUND(NVL(FEV_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS FEV_PERC,
       ROUND(NVL(MAR_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS MAR_PERC,
       ROUND(NVL(ABR_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS ABR_PERC,
       ROUND(NVL(MAI_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS MAI_PERC,
       ROUND(NVL(JUN_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS JUN_PERC,
       ROUND(NVL(JUL_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS JUL_PERC,
       ROUND(NVL(AGO_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS AGO_PERC,
       ROUND(NVL(SET_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS SET_PERC,
       ROUND(NVL(OUT_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS OUT_PERC,
       ROUND(NVL(NOV_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS NOV_PERC,
       ROUND(NVL(DEZ_PROD / NULLIF(ESTMAX,0) * 100,0),2) AS DEZ_PERC
      FROM custos c
)
SELECT grupo_n1,descr_n1,grupo_n2,descr_n2,grupo_n3,descr_n3,grupo_n4,descr_n4,
       codprod,descrprod,
       CASE WHEN estoqueatual>=estmin THEN '#16852B' ELSE '#D32F2F' END cor_status,
       codwcp,nome,maq_producao,estoqueatual,estmin,estmax,
       JAN_PROD, JAN_PERC,
       FEV_PROD, FEV_PERC,
       MAR_PROD, MAR_PERC,
       ABR_PROD, ABR_PERC,
       MAI_PROD, MAI_PERC,
       JUN_PROD, JUN_PERC,
       JUL_PROD, JUL_PERC,
       AGO_PROD, AGO_PERC,
       SET_PROD, SET_PERC,
       OUT_PROD, OUT_PERC,
       NOV_PROD, NOV_PERC,
       DEZ_PROD, DEZ_PERC
  FROM resultado
 ORDER BY grupo_n1,grupo_n2,grupo_n3,grupo_n4,codprod
    ]]></snk:query>
    <table>
      <thead><tr><th>Código</th><th>Descrição do Produto</th><th>Situação</th><th>Cod. CT</th><th>Centro de Trabalho</th><th>Máquina</th><th>Est. Atual</th><th>Est. Mín.</th><th>Est. Máx.</th><th>Custo Jan</th><th>% Jan</th><th>Custo Fev</th><th>% Fev</th><th>Custo Mar</th><th>% Mar</th><th>Custo Abr</th><th>% Abr</th><th>Custo Mai</th><th>% Mai</th><th>Custo Jun</th><th>% Jun</th><th>Custo Jul</th><th>% Jul</th><th>Custo Ago</th><th>% Ago</th><th>Custo Set</th><th>% Set</th><th>Custo Out</th><th>% Out</th><th>Custo Nov</th><th>% Nov</th><th>Custo Dez</th><th>% Dez</th></tr></thead>
      <tbody>
        <c:forEach items="${produtos.rows}" var="row">
          <tr><td><c:out value="${row.CODPROD}"/></td><td><c:out value="${row.DESCRPROD}"/></td><td class="numero"><span class="status" style="background-color:${row.COR_STATUS};"></span></td><td><c:out value="${row.CODWCP}"/></td><td><c:out value="${row.NOME}"/></td><td><c:out value="${row.MAQ_PRODUCAO}"/></td><td class="numero"><c:out value="${row.ESTOQUEATUAL}"/></td><td class="numero"><c:out value="${row.ESTMIN}"/></td><td class="numero"><c:out value="${row.ESTMAX}"/></td><td class="numero"><c:out value="${row.JAN_PROD}"/></td><td class="numero"><c:out value="${row.JAN_PERC}"/></td><td class="numero"><c:out value="${row.FEV_PROD}"/></td><td class="numero"><c:out value="${row.FEV_PERC}"/></td><td class="numero"><c:out value="${row.MAR_PROD}"/></td><td class="numero"><c:out value="${row.MAR_PERC}"/></td><td class="numero"><c:out value="${row.ABR_PROD}"/></td><td class="numero"><c:out value="${row.ABR_PERC}"/></td><td class="numero"><c:out value="${row.MAI_PROD}"/></td><td class="numero"><c:out value="${row.MAI_PERC}"/></td><td class="numero"><c:out value="${row.JUN_PROD}"/></td><td class="numero"><c:out value="${row.JUN_PERC}"/></td><td class="numero"><c:out value="${row.JUL_PROD}"/></td><td class="numero"><c:out value="${row.JUL_PERC}"/></td><td class="numero"><c:out value="${row.AGO_PROD}"/></td><td class="numero"><c:out value="${row.AGO_PERC}"/></td><td class="numero"><c:out value="${row.SET_PROD}"/></td><td class="numero"><c:out value="${row.SET_PERC}"/></td><td class="numero"><c:out value="${row.OUT_PROD}"/></td><td class="numero"><c:out value="${row.OUT_PERC}"/></td><td class="numero"><c:out value="${row.NOV_PROD}"/></td><td class="numero"><c:out value="${row.NOV_PERC}"/></td><td class="numero"><c:out value="${row.DEZ_PROD}"/></td><td class="numero"><c:out value="${row.DEZ_PERC}"/></td></tr>
        </c:forEach>
        <c:if test="${empty produtos.rows}"><tr><td colspan="33" class="vazio">Selecione um grupo no Nível 04 para carregar os produtos.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div>
</body></html>
