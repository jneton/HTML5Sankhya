<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html><head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/estoque.css">
<snk:load/>
<script type="text/javascript">
function selecionar(codigo) {
  refreshDetails('html5_est_n4', {GRUPOPAI: codigo});
  refreshDetails('html5_est_produtos', {GRUPO: -1});
}
</script>
</head><body>
<div class="painel">
  <div class="titulo">Nível 03</div>
  <div class="grade-wrap">
    <snk:query var="dados">WITH mapa_grupos AS (
    SELECT g3.codgrupoprod grupo_n3, g3.codgrupoprod grupo_produto
      FROM tgfgru g2 JOIN tgfgru g3 ON g3.codgrupai=g2.codgrupoprod AND g3.grau=3
     WHERE g2.grau=2 AND g2.codgrupoprod=:GRUPOPAI
    UNION ALL
    SELECT g3.codgrupoprod, g4.codgrupoprod
      FROM tgfgru g2 JOIN tgfgru g3 ON g3.codgrupai=g2.codgrupoprod AND g3.grau=3
      JOIN tgfgru g4 ON g4.codgrupai=g3.codgrupoprod AND g4.grau=4
     WHERE g2.grau=2 AND g2.codgrupoprod=:GRUPOPAI
),
estoque AS (SELECT codprod,SUM(NVL(estoque,0)) estoqueatual FROM tgfest GROUP BY codprod),
produtos AS (SELECT codprod,codgrupoprod,NVL(estmax,0) estmax FROM tgfpro
              WHERE (NVL(UPPER(:P_ATIVO),'T')='T'
                  OR (UPPER(:P_ATIVO)='A' AND ativo='S')
                  OR (UPPER(:P_ATIVO)='I' AND ativo='N'))),
base AS (
    SELECT m.grupo_n3,p.codprod,p.estmax,NVL(e.estoqueatual,0) estoqueatual
      FROM mapa_grupos m JOIN produtos p ON p.codgrupoprod=m.grupo_produto
      LEFT JOIN estoque e ON e.codprod=p.codprod
)
SELECT g.codgrupoprod grupo_n3,g.descrgrupoprod descr_n3,
       NVL(SUM(b.estmax),0) estmax,NVL(SUM(b.estoqueatual),0) estoqueatual,
       NVL(ROUND(SUM(b.estoqueatual)/NULLIF(SUM(b.estmax),0),4),0)*100 pct
  FROM tgfgru g LEFT JOIN base b ON b.grupo_n3=g.codgrupoprod
 WHERE g.grau=3 AND g.codgrupai=:GRUPOPAI AND g.ativo='S'
 GROUP BY g.codgrupoprod,g.descrgrupoprod ORDER BY g.codgrupoprod
    </snk:query>
    <table>
      <thead><tr><th>Descrição</th><th class="numero">Est. Máx.</th><th class="numero">Est. Atual</th><th class="numero">%</th></tr></thead>
      <tbody>
        <c:forEach items="${dados.rows}" var="row">
          <tr class="selecionavel" onclick="selecionar(${row.GRUPO_N3})">
            <td><button class="selecao" type="button" onclick="event.stopPropagation(); selecionar(${row.GRUPO_N3});"><c:out value="${row.DESCR_N3}"/></button></td>
            <td class="numero"><c:out value="${row.ESTMAX}"/></td>
            <td class="numero"><c:out value="${row.ESTOQUEATUAL}"/></td>
            <td class="percentual"><c:out value="${row.PCT}"/>%</td>
          </tr>
        </c:forEach>
        <c:if test="${empty dados.rows}"><tr><td colspan="4" class="vazio">Selecione um grupo no nível anterior.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div>
</body></html>
