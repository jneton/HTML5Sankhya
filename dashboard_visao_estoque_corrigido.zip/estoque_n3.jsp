<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html><head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/estoque.css">
<snk:load/>
<script type="text/javascript">
function selecionar(codigo) {
  refreshDetails('html5_est_n4', {GRUPOPAI: codigo});
  refreshDetails('html5_est_produtos', {GRUPO: -1});
}
</script>
</head><body>
<div class="painel">
  <div class="titulo">Nível 03</div>
  <div class="grade-wrap">
    <snk:query var="dados">
WITH grupos_exibicao AS (
    SELECT codgrupoprod AS codgrupo, descrgrupoprod AS descricao
      FROM tgfgru
     WHERE grau = 3 AND ativo = 'S' AND codgrupai = :GRUPOPAI
),
-- Descendentes inclui o próprio grupo e todos os níveis abaixo dele.
grupos_descendentes AS (
    SELECT CONNECT_BY_ROOT g.codgrupoprod AS grupo_exibicao,
           g.codgrupoprod AS grupo_produto
      FROM tgfgru g
     START WITH g.codgrupoprod IN (SELECT codgrupo FROM grupos_exibicao)
   CONNECT BY NOCYCLE PRIOR g.codgrupoprod = g.codgrupai
),
produtos_filtrados AS (
    SELECT p.codprod, p.codgrupoprod, NVL(p.estmax, 0) AS estmax
      FROM tgfpro p
     WHERE UPPER(NVL(:P_ATIVO, 'T')) = 'T'
        OR (UPPER(:P_ATIVO) = 'A' AND p.ativo = 'S')
        OR (UPPER(:P_ATIVO) = 'I' AND p.ativo = 'N')
),
estoque AS (
    SELECT codprod, SUM(NVL(estoque, 0)) AS estoqueatual
      FROM tgfest
     GROUP BY codprod
),
totais AS (
    SELECT d.grupo_exibicao,
           SUM(p.estmax) AS estmax,
           SUM(NVL(e.estoqueatual, 0)) AS estoqueatual
      FROM grupos_descendentes d
      JOIN produtos_filtrados p ON p.codgrupoprod = d.grupo_produto
      LEFT JOIN estoque e ON e.codprod = p.codprod
     GROUP BY d.grupo_exibicao
)
SELECT g.codgrupo AS codgrupo,
       g.descricao AS descricao,
       NVL(t.estmax, 0) AS estmax,
       NVL(t.estoqueatual, 0) AS estoqueatual,
       NVL(ROUND(t.estoqueatual / NULLIF(t.estmax, 0) * 100, 2), 0) AS pct
  FROM grupos_exibicao g
  LEFT JOIN totais t ON t.grupo_exibicao = g.codgrupo
 ORDER BY g.codgrupo 
    </snk:query>
    <table>
      <thead><tr><th>Descrição</th><th class="numero">Est. Máx.</th><th class="numero">Est. Atual</th><th class="numero">%</th></tr></thead>
      <tbody>
        <c:forEach items="${dados.rows}" var="row">
          <tr class="selecionavel" onclick="selecionar(${row.CODGRUPO})">
            <td><button class="selecao" type="button" onclick="event.stopPropagation(); selecionar(${row.CODGRUPO});"><c:out value="${row.DESCRICAO}"/></button></td>
            <td class="numero"><c:out value="${row.ESTMAX}"/></td>
            <td class="numero"><c:out value="${row.ESTOQUEATUAL}"/></td>
            <td class="percentual"><c:out value="${row.PCT}"/>%</td>
          </tr>
        </c:forEach>
        <c:if test="${empty dados.rows}"><tr><td colspan="4" class="vazio">Nenhum grupo encontrado para os filtros selecionados.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div>
</body></html>
