<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ordens de Carga | Haiala</title>
  <link rel="stylesheet" href="${BASE_FOLDER}/css/dashboardCSS.css">
  <snk:load/>
</head>
<body>
<snk:query var="dados">
WITH
ordens_filtradas AS (
 SELECT DISTINCT CAB.ORDEMCARGA
 FROM TGFCAB CAB LEFT JOIN TGFORD ORD ON ORD.ORDEMCARGA=CAB.ORDEMCARGA
 WHERE CAB.TIPMOV='P' AND CAB.PENDENTE='S'
   AND CAB.ORDEMCARGA IN :P_OC
   AND (:SIT = 'T' OR COALESCE(ORD.AD_FORMCONC,'N') = :SIT)
),
itens_base AS (
 SELECT CAB.ORDEMCARGA, ITE.NUNOTA, ITE.CODPROD, ITE.QTDNEG,
        ITE.QTDENTREGUE, ITE.QTDCONFERIDA, ITE.AD_VLRLIQ,
        ITE.AD_VLRUNITFRETE, ITE.OBSERVACAO,
        (ITE.QTDNEG-ITE.QTDENTREGUE-ITE.QTDCONFERIDA) QTD_PENDENTE
 FROM TGFCAB CAB JOIN TGFITE ITE ON ITE.NUNOTA=CAB.NUNOTA
 JOIN ordens_filtradas OFI ON OFI.ORDEMCARGA=CAB.ORDEMCARGA
 WHERE CAB.TIPMOV='P' AND CAB.PENDENTE='S' AND ITE.PENDENTE='S'
),
estoque AS (
 SELECT EST.CODPROD,
        SUM(CASE WHEN EST.CODPARC=0 AND EST.CODLOCAL<>2030000 THEN NVL(EST.ESTOQUE,0) ELSE 0 END) ESTOQUE_DISP,
        SUM(CASE WHEN EST.CODPARC=0 AND EST.CODLOCAL=2030000 THEN NVL(EST.ESTOQUE,0) ELSE 0 END) ESTOQUE_DEF,
        SUM(CASE WHEN EST.CODLOCAL=2010000 THEN NVL(EST.ESTOQUE,0) ELSE 0 END) ESTOQUE_SA
 FROM TGFEST EST WHERE EST.CODPARC=0 OR EST.CODLOCAL=2010000 GROUP BY EST.CODPROD
),
produto_sa_base AS (
 SELECT PRO.CODPROD, PRO.AD_COD_PROD_SA COD_SA_1,
        SUBSTR(SA1.CODGRUPOPROD,1,3) GRUPO_SA_1, PROSA.AD_COD_PROD_SA COD_SA_2
 FROM TGFPRO PRO LEFT JOIN TGFPRO PROSA ON PROSA.CODPROD=PRO.AD_COD_PROD_SA
 LEFT JOIN TGFPRO SA1 ON SA1.CODPROD=PRO.AD_COD_PROD_SA
 WHERE SUBSTR(PRO.CODGRUPOPROD,1,1)='4'
),
produto_sa AS (
 SELECT CODPROD,
        CASE WHEN GRUPO_SA_1='301' THEN COD_SA_1 ELSE COD_SA_2 END CODPRO_SA,
        CASE WHEN GRUPO_SA_1='301' THEN NULL ELSE COD_SA_1 END CODPRO_PINT
 FROM produto_sa_base
),
resumo_oc AS (
 SELECT IB.CODPROD, IB.ORDEMCARGA, SUM(IB.QTD_PENDENTE) QTD_OC
 FROM itens_base IB GROUP BY IB.CODPROD, IB.ORDEMCARGA
),
resumo_oc_texto AS (
 SELECT CODPROD, LISTAGG('OC '||TO_CHAR(ORDEMCARGA)||': '||TO_CHAR(QTD_OC),' | ')
        WITHIN GROUP(ORDER BY ORDEMCARGA) DETALHE_OC
 FROM resumo_oc GROUP BY CODPROD
),
observacoes AS (
 SELECT CODPROD, COUNT(DISTINCT CASE WHEN OBSERVACAO IS NOT NULL THEN NUNOTA END) QTDPEDOBS,
        LISTAGG(CASE WHEN OBSERVACAO IS NOT NULL THEN 'OC: '||TO_CHAR(ORDEMCARGA)||' Ped: '||TO_CHAR(NUNOTA) END, ', ')
        WITHIN GROUP(ORDER BY NUNOTA) PEDCOMOBS
 FROM (SELECT DISTINCT CODPROD, NUNOTA, ORDEMCARGA, OBSERVACAO FROM itens_base)
 GROUP BY CODPROD
),
resumo_produto AS (
 SELECT GRU.CODGRUPOPROD, GRU.DESCRGRUPOPROD, IB.CODPROD, PRO.DESCRPROD, PRO.MARCA,
        NVL(OBS.QTDPEDOBS,0) QTDPEDOBS, OBS.PEDCOMOBS, PSA.CODPRO_SA,
        NVL(ESA.ESTOQUE_SA,0) ESTSA, PSA.CODPRO_PINT, NVL(ESP.ESTOQUE_SA,0) ESTPINT,
        SUM(IB.QTD_PENDENTE) PENDENTE, NVL(EST.ESTOQUE_DISP,0) ESTOQUE,
        NVL(EST.ESTOQUE_DEF,0) ESTOQUE_DEF,
        NVL(EST.ESTOQUE_DISP,0)-SUM(IB.QTD_PENDENTE) DIF,
        SUM(CASE WHEN IB.QTDNEG<>0 THEN IB.QTD_PENDENTE*(IB.AD_VLRLIQ/IB.QTDNEG) ELSE 0 END) VLTTOT,
        SUM(IB.QTD_PENDENTE*NVL(IB.AD_VLRUNITFRETE,0)) FRETE,
        NVL(PRO.ESTMIN,0) ESTMIN, PRO.M3 M3_PROD, ROC.DETALHE_OC
 FROM itens_base IB JOIN TGFPRO PRO ON PRO.CODPROD=IB.CODPROD
 JOIN TGFGRU GRU ON GRU.CODGRUPOPROD=PRO.CODGRUPOPROD
 LEFT JOIN estoque EST ON EST.CODPROD=IB.CODPROD
 LEFT JOIN produto_sa PSA ON PSA.CODPROD=IB.CODPROD
 LEFT JOIN estoque ESA ON ESA.CODPROD=PSA.CODPRO_SA
 LEFT JOIN estoque ESP ON ESP.CODPROD=PSA.CODPRO_PINT
 LEFT JOIN observacoes OBS ON OBS.CODPROD=IB.CODPROD
 LEFT JOIN resumo_oc_texto ROC ON ROC.CODPROD=IB.CODPROD
 GROUP BY GRU.CODGRUPOPROD, GRU.DESCRGRUPOPROD, IB.CODPROD, PRO.DESCRPROD, PRO.MARCA,
          OBS.QTDPEDOBS, OBS.PEDCOMOBS, PSA.CODPRO_SA, ESA.ESTOQUE_SA,
          PSA.CODPRO_PINT, ESP.ESTOQUE_SA, EST.ESTOQUE_DISP, EST.ESTOQUE_DEF,
          PRO.ESTMIN, PRO.M3, ROC.DETALHE_OC
)
SELECT LPAD(TO_CHAR(RP.CODGRUPOPROD),10,'0') CODGRUPPROD, RP.DESCRGRUPOPROD,
       RP.CODPROD, RP.DESCRPROD, RP.MARCA, RP.QTDPEDOBS, RP.PEDCOMOBS,
       RP.PENDENTE, RP.ESTOQUE, RP.ESTOQUE_DEF, GREATEST(RP.DIF,0) DIFPOS,
       LEAST(RP.DIF,0) DIFNEG,
       CASE WHEN RP.DIF>0 THEN 'Sobrando' ELSE 'Faltando' END SITUACAO,
       RP.CODPRO_SA, RP.ESTSA, RP.CODPRO_PINT, RP.ESTPINT, RP.VLTTOT, RP.FRETE,
       RP.ESTMIN, CASE WHEN RP.DIF<=0 THEN 'RED' WHEN RP.DIF<=RP.ESTMIN THEN 'YELLOW' ELSE 'BLUE' END FAROL,
       RP.M3_PROD, RP.DETALHE_OC,
       OPTION_LABEL('TGFPRO','AD_SET_PRODUCAO',(SELECT P.AD_SET_PRODUCAO FROM TGFPRO P WHERE P.CODPROD=RP.CODPRO_SA)) SET_SA
FROM resumo_produto RP ORDER BY RP.CODPROD
</snk:query>
<div class="page">
  <header class="topbar">
    <div><div class="eyebrow">HAIALA · LOGÍSTICA E EXPEDIÇÃO</div><h1>Ordens de Carga</h1><p>Posição de pedidos pendentes e disponibilidade de estoque</p></div>
    <div class="header-tag">PAINEL OPERACIONAL</div>
  </header>
  <c:set var="totalProdutos" value="0"/><c:set var="totalPendente" value="0"/>
  <c:set var="totalEstoque" value="0"/><c:set var="totalFaltantes" value="0"/>
  <c:set var="totalFrete" value="0"/><c:set var="totalVolume" value="0"/>
  <c:forEach items="${dados.rows}" var="r">
    <c:set var="totalProdutos" value="${totalProdutos + 1}"/>
    <c:set var="totalPendente" value="${totalPendente + r.PENDENTE}"/>
    <c:set var="totalEstoque" value="${totalEstoque + r.ESTOQUE}"/>
    <c:set var="totalFrete" value="${totalFrete + r.FRETE}"/>
    <c:set var="totalVolume" value="${totalVolume + (r.M3_PROD * r.PENDENTE)}"/>
    <c:if test="${r.DIFNEG lt 0}"><c:set var="totalFaltantes" value="${totalFaltantes + 1}"/></c:if>
  </c:forEach>
  <section class="kpis">
    <article class="kpi"><span>Produtos</span><strong><c:out value="${totalProdutos}"/></strong><small>itens distintos</small></article>
    <article class="kpi"><span>Quantidade pendente</span><strong><c:out value="${totalPendente}"/></strong><small>unidades a atender</small></article>
    <article class="kpi kpi-alert"><span>Produtos faltantes</span><strong><c:out value="${totalFaltantes}"/></strong><small>estoque abaixo da demanda</small></article>
    <article class="kpi"><span>Estoque disponível</span><strong><c:out value="${totalEstoque}"/></strong><small>saldo consolidado</small></article>
    <article class="kpi"><span>Frete pendente</span><strong><c:out value="${totalFrete}"/></strong><small>valor estimado</small></article>
    <article class="kpi"><span>Volume pendente</span><strong><c:out value="${totalVolume}"/></strong><small>m³ estimados</small></article>
  </section>
  <section class="panel">
    <div class="panel-head"><div><h2>Produtos por disponibilidade</h2><p>Filtre a grade por código, descrição, marca ou situação</p></div>
      <div class="search-wrap"><input id="filtroProduto" type="search" placeholder="Buscar produto..." oninput="filtrarTabela()"></div>
    </div>
    <div class="table-wrap"><table id="tabelaProdutos">
      <thead><tr><th>Farol</th><th>Produto</th><th>Grupo</th><th>Marca</th><th class="num">Pendente</th><th class="num">Estoque</th><th class="num">Est. definido</th><th class="num">Diferença</th><th>Situação</th><th class="num">SA</th><th class="num">Est. SA</th><th>Conjunto SA</th><th class="num">Pintura</th><th class="num">Est. pintura</th><th class="num">Valor</th><th class="num">Frete</th><th>Ordens de carga</th><th>Pedidos observados</th></tr></thead>
      <tbody>
      <c:forEach items="${dados.rows}" var="r">
        <tr data-search="${r.CODPROD} ${r.DESCRPROD} ${r.MARCA} ${r.SITUACAO}">
          <td><span class="signal ${r.FAROL}"></span></td>
          <td><b><c:out value="${r.CODPROD}"/></b><small class="subcell"><c:out value="${r.DESCRPROD}"/></small></td>
          <td><c:out value="${r.CODGRUPPROD}"/></td><td><c:out value="${r.MARCA}"/></td>
          <td class="num"><c:out value="${r.PENDENTE}"/></td><td class="num"><c:out value="${r.ESTOQUE}"/></td>
          <td class="num"><c:out value="${r.ESTOQUE_DEF}"/></td><td class="num"><b><c:out value="${r.DIFPOS + r.DIFNEG}"/></b></td>
          <td><span class="status ${r.DIFNEG lt 0 ? 'missing' : 'available'}"><c:out value="${r.SITUACAO}"/></span></td>
          <td class="num"><c:out value="${r.CODPRO_SA}"/></td><td class="num"><c:out value="${r.ESTSA}"/></td><td><c:out value="${r.SET_SA}"/></td>
          <td class="num"><c:out value="${r.CODPRO_PINT}"/></td><td class="num"><c:out value="${r.ESTPINT}"/></td>
          <td class="num"><c:out value="${r.VLTTOT}"/></td><td class="num"><c:out value="${r.FRETE}"/></td>
          <td class="detail"><c:out value="${r.DETALHE_OC}"/></td><td class="detail"><c:out value="${r.PEDCOMOBS}"/></td>
        </tr>
      </c:forEach>
      </tbody>
    </table></div>
    <div class="table-foot"><span id="contadorLinhas">Exibindo <c:out value="${totalProdutos}"/> produtos</span><span>Atualize os parâmetros do dashboard para alterar as ordens e a situação</span></div>
  </section>
  <footer>Haiala Metalúrgica · Dashboard de Ordens de Carga</footer>
</div>
<script>
function filtrarTabela(){
  var campo=document.getElementById('filtroProduto');
  var termo=(campo.value||'').toLocaleLowerCase('pt-BR');
  var linhas=document.querySelectorAll('#tabelaProdutos tbody tr');
  var visiveis=0;
  linhas.forEach(function(linha){
    var texto=(linha.getAttribute('data-search')||'').toLocaleLowerCase('pt-BR');
    var exibir=texto.indexOf(termo)>=0;
    linha.style.display=exibir?'':'none';
    if(exibir) visiveis++;
  });
  document.getElementById('contadorLinhas').textContent='Exibindo '+visiveis+' de '+linhas.length+' produtos';
}
</script>
</body>
</html>
