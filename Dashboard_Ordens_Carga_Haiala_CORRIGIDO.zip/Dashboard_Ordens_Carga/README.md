# Dashboard de Ordens de Carga - Haiala

Pacote organizado para o caminho de componente observado no Sankhya:
`Dashboard_Ordens_Carga/dashboard.jsp`.

## Conteúdo
- `dashboard.jsp`: componente HTML5 usando `snk:load` e `executeQuery`.
- `model_XML_Oracle.xml`: parâmetros `P_OC` e `SIT` e entrada `dashboard.jsp`.
- `css/dashboardCSS.css`: estilos.
- `sql/`: consultas de referência.

## Publicação
Publique/substitua a pasta `Dashboard_Ordens_Carga` mantendo esse nome, sem criar uma pasta adicional `ordens_carga_modelo` dentro dela. Confirme que o XML do gadget referencia `entryPoint="dashboard.jsp"` e que a URL resultante contém `/Dashboard_Ordens_Carga/dashboard.jsp`.

## Limite da validação
O JSP/JavaScript e o XML foram inspecionados estruturalmente. A execução real depende do ambiente Sankhya, das permissões, dos parâmetros e do banco Oracle da Haiala; este pacote não está homologado em servidor.
