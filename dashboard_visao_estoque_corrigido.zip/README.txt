# Dashboard Visão do Estoque – versão corrigida

## Arquivos
- `model_XML_Oracle.xml`: modelo do gadget, prompt P_ATIVO e IDs dos cinco componentes.
- `estoque_n1.jsp` a `estoque_n4.jsp`: níveis de agrupamento.
- `estoque_produtos.jsp`: detalhamento dos produtos e custos mensais.
- `css/estoque.css`: estilos.

## Correções aplicadas
1. Padronizados os IDs usados por `refreshDetails()` com os IDs declarados no XML:
   - `html5_est_n2`
   - `html5_est_n3`
   - `html5_est_n4`
   - `html5_est_produtos`
2. Reescrita a agregação dos níveis 1, 2 e 3 com hierarquia descendente (`CONNECT BY NOCYCLE`). Assim, os totais consideram produtos associados ao próprio grupo e aos seus subgrupos, sem depender de existir exatamente quatro níveis.
3. Nível 4 agora exibe o grupo de nível 3 (para produtos cadastrados diretamente nele) e os grupos de nível 4. Ao clicar em qualquer linha, o detalhe recebe o código exato do grupo selecionado.
4. A consulta de produtos deixou de depender de um `JOIN` com a combinação de níveis mais profundos. Agora filtra diretamente por `TGFPRO.CODGRUPOPROD = :GRUPO`, evitando excluir produtos cadastrados diretamente em grupos intermediários.
5. O filtro `P_ATIVO` foi aplicado tanto nas consultas de totais quanto na consulta detalhada:
   - `A`: somente `TGFPRO.ATIVO = 'S'`;
   - `I`: somente `TGFPRO.ATIVO = 'N'`;
   - `T`: todos.
6. Ao selecionar um grupo em um nível, os níveis posteriores são limpos para evitar que permaneçam dados de uma seleção anterior.

## Instalação – importante para o CORE_E05294
O erro `Não foi encontrado o elemento detail` ocorre quando o `refreshDetails()` solicita um identificador que não está registrado no modelo carregado pelo gadget. Os IDs estão consistentes entre os JSPs e este XML; por isso, publique também o `model_XML_Oracle.xml` atualizado. Não basta substituir somente os JSPs.

Procedimento recomendado:
1. Faça backup da versão atual.
2. Atualize/publice o XML do gadget com o conteúdo deste pacote.
3. Publique os JSPs e a pasta `css` nos respectivos caminhos.
4. Reabra o gadget ou remova e adicione novamente o gadget de TESTE para garantir que o modelo atualizado foi carregado.
5. Teste a navegação Nível 1 → Nível 2 → Nível 3 → Nível 4 → Produtos.
6. Teste `P_ATIVO` nas três opções: Ativos, Inativos e Todos.

## Observações
- O pacote foi revisado estaticamente, mas não foi executado dentro do servidor Sankhya nem conectado ao Oracle da Haiala. É necessário homologar em TESTE.
- A consulta de produtos mantém a função `FC_CUSTOEST_HAI5` para os fechamentos mensais. O tempo de resposta pode variar conforme a quantidade de produtos retornados.
- Se o erro `CORE_E05294` persistir após publicar o XML atualizado, confira no XML efetivamente publicado se os IDs dos componentes são exatamente iguais aos listados acima e se o gadget está apontando para esse modelo.
