<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8"  isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Painel Industrial</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

/* ==========================================================
   RESET
========================================================== */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

:root{

    --bg:#f4f6f9;
    --card:#ffffff;

    --primary:#1f4e79;
    --success:#8bc34a;
    --warning:#ff9800;
    --danger:#f44336;

    --text:#2c3e50;
    --border:#dce1e7;
}

body{
    background:var(--bg);
    font-family:Segoe UI,Tahoma,sans-serif;
    color:var(--text);
}

/* ==========================================================
   HEADER
========================================================== */

.header{
    background:var(--primary);
    color:white;
    padding:15px 20px;
    box-shadow:0 2px 5px rgba(0,0,0,.15);
}

.header h1{
    font-size:24px;
}

/* ==========================================================
   DASHBOARD
========================================================== */

.dashboard{

    display:grid;

    grid-template-columns:
        repeat(12,1fr);

    gap:15px;

    padding:15px;
}

.card{

    background:var(--card);

    border-radius:8px;

    box-shadow:
        0 2px 6px rgba(0,0,0,.08);

    padding:12px;
}

.card h3{

    font-size:15px;

    margin-bottom:10px;

    color:var(--primary);
}

/* ==========================================================
   GRID
========================================================== */

.span-12{grid-column:span 12;}
.span-8{grid-column:span 8;}
.span-6{grid-column:span 6;}
.span-4{grid-column:span 4;}
.span-3{grid-column:span 3;}

/* ==========================================================
   TABLE
========================================================== */

table{
    width:100%;
    border-collapse:collapse;
}

thead{
    background:#e8edf3;
}

th{
    text-align:left;
    padding:8px;
    font-size:12px;
}

td{
    padding:7px;
    border-bottom:1px solid #eee;
    font-size:12px;
}

tbody tr:hover{
    background:#f9fbfc;
}

/* ==========================================================
   ACTIONS
========================================================== */

.action{

    border-left:4px solid var(--warning);

    background:#fff9ec;

    padding:10px;

    margin-bottom:10px;
}

/* ==========================================================
   ROUTINES
========================================================== */

.routines{

    display:grid;

    grid-template-columns:
        repeat(auto-fit,minmax(220px,1fr));

    gap:10px;
}

.routines ul{
    list-style:none;
}

.routines li{
    padding:4px 0;
}

/* ==========================================================
   RESPONSIVO
========================================================== */

@media(max-width:1200px){

    .span-8,
    .span-6,
    .span-4,
    .span-3{
        grid-column:span 12;
    }

}

canvas{
    width:100% !important;
    height:300px !important;
}

</style>

</head>

<body>

<header class="header">
    <h1>Painel Industrial de Produção</h1>
</header>

<main class="dashboard">

    <!-- EFICIENCIA -->
    <section class="card span-6">

        <h3>% EFICIÊNCIA (MENSAL)</h3>

        <canvas id="eficiencia"></canvas>

    </section>

    <!-- PRODUCAO -->
    <section class="card span-6">

        <h3>QTE PRODUZIDA (1º TURNO)</h3>

        <canvas id="producao"></canvas>

    </section>

    <!-- QUALIDADE -->
    <section class="card span-3">

        <h3>QUALIDADE</h3>

        <canvas id="qualidade"></canvas>

    </section>

    <!-- OCORRENCIAS -->
    <section class="card span-3">

        <h3>OCORRÊNCIAS NA OP</h3>

        <table>

            <thead>
                <tr>
                    <th>Classificação</th>
                    <th>Freq</th>
                    <th>%</th>
                </tr>
            </thead>

            <tbody>

                <tr>
                    <td>Manutenção</td>
                    <td>15</td>
                    <td>7,5%</td>
                </tr>

                <tr>
                    <td>Retrabalho</td>
                    <td>16</td>
                    <td>12,5%</td>
                </tr>

                <tr>
                    <td>Falha Abastecimento</td>
                    <td>17</td>
                    <td>17,5%</td>
                </tr>

                <tr>
                    <td>Setup</td>
                    <td>18</td>
                    <td>22,5%</td>
                </tr>

            </tbody>

        </table>

    </section>

    <!-- RANKING -->
    <section class="card span-3">

        <h3>RANKING DE O.S.</h3>

        <table>

            <thead>
                <tr>
                    <th>Equipamento</th>
                    <th>Qtd</th>
                </tr>
            </thead>

            <tbody>

                <tr>
                    <td>Equipamento Manutenção</td>
                    <td>12</td>
                </tr>

                <tr>
                    <td>Máquina Arquear</td>
                    <td>6</td>
                </tr>

                <tr>
                    <td>Bomba Centrífuga</td>
                    <td>3</td>
                </tr>

                <tr>
                    <td>Queimador</td>
                    <td>3</td>
                </tr>

            </tbody>

        </table>

    </section>

    <!-- PLANO ACAO -->
    <section class="card span-3">

        <h3>PLANO DE AÇÃO</h3>

        <div class="action">
            <strong>17/Mar</strong><br>
            Troca do Manômetro Máquina Solda Ponto
        </div>

        <div class="action">
            <strong>18/Mar</strong><br>
            Revisão Preventiva Compressor
        </div>

    </section>

    <!-- MANUTENCAO -->
    <section class="card span-6">

        <h3>MANUTENÇÃO (ORDENS DE SERVIÇO)</h3>

        <table>

            <thead>

                <tr>
                    <th>Status</th>
                    <th>Corretiva</th>
                    <th>Melhoria</th>
                    <th>Preventiva</th>
                    <th>Programada</th>
                    <th>Total</th>
                </tr>

            </thead>

            <tbody>

                <tr>
                    <td>Aguardando</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>1</td>
                    <td>1</td>
                </tr>

                <tr>
                    <td>Finalizado</td>
                    <td>7</td>
                    <td>1</td>
                    <td>10</td>
                    <td>0</td>
                    <td>18</td>
                </tr>

            </tbody>

        </table>

    </section>

    <!-- DESPERDICIOS -->
    <section class="card span-6">

        <h3>DESPERDÍCIOS / PERDAS</h3>

        <table>

            <thead>

                <tr>
                    <th>Produto</th>
                    <th>Qtd</th>
                    <th>Custo</th>
                </tr>

            </thead>

            <tbody>

                <tr>
                    <td>P Vent Reto</td>
                    <td>109,86</td>
                    <td>R$ 3.136,70</td>
                </tr>

                <tr>
                    <td>P Vent Branco</td>
                    <td>131,02</td>
                    <td>R$ 3.135,70</td>
                </tr>

                <tr>
                    <td>P Vent Extra</td>
                    <td>114,40</td>
                    <td>R$ 3.131,70</td>
                </tr>

            </tbody>

        </table>

    </section>

    <!-- ROTINAS -->
    <section class="card span-12">

        <h3>ROTINAS NO SETOR</h3>

        <div class="routines">

            <ul>
                <li>✓ Orientação Time</li>
                <li>✓ Abastecimento D-1</li>
                <li>✓ Controle Hora a Hora</li>
                <li>✓ Segregação Diária</li>
                <li>✓ Plano de Produção</li>
            </ul>

            <ul>
                <li>✓ DDS e DDQ</li>
                <li>✓ Inspeção Pontos Críticos</li>
                <li>✓ Premiação</li>
                <li>✓ Pontos Manutenção</li>
                <li>✓ Prioridades Produção</li>
            </ul>

            <ul>
                <li>✓ Treinamentos</li>
                <li>✓ Feedback Individual</li>
            </ul>

        </div>

    </section>

</main>

<script>

/* ==========================================================
   EFICIENCIA
========================================================== */

new Chart(
document.getElementById('eficiencia'),
{
    type:'bar',

    data:{

        labels:[
            'Jan',
            'Fev',
            'Mar',
            'Abr',
            'Mai',
            'Jun',
            'Jul',
            'Ago',
            'Set'
        ],

        datasets:[{

            label:'Eficiência %',

            data:[
                88,
                89,
                73,
                73,
                86,
                88,
                90,
                88,
                81
            ]

        }]
    },

    options:{
        responsive:true,
        plugins:{
            legend:{
                display:false
            }
        }
    }
});

/* ==========================================================
   PRODUCAO
========================================================== */

new Chart(
document.getElementById('producao'),
{
    type:'bar',

    data:{

        labels:[
            'S1',
            'S2',
            'S3',
            'S4',
            'S5',
            'S6',
            'S7',
            'S8',
            'S9'
        ],

        datasets:[{

            label:'Produção',

            data:[
                178,
                120,
                134,
                136,
                180,
                175,
                140,
                122,
                145
            ]

        }]
    },

    options:{
        responsive:true,
        plugins:{
            legend:{
                display:false
            }
        }
    }
});

/* ==========================================================
   QUALIDADE
========================================================== */

new Chart(
document.getElementById('qualidade'),
{
    type:'bar',

    data:{

        labels:[
            'Notificado',
            'Retido',
            'Reprovado'
        ],

        datasets:[{

            data:[
                5,
                2,
                1
            ]
        }]
    },

    options:{
        indexAxis:'y',

        plugins:{
            legend:{
                display:false
            }
        }
    }
});

</script>

</body>
</html>