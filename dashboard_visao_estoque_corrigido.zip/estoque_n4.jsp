<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html><head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/estoque.css">
<snk:load/>
<script type="text/javascript">
function selecionar(codigo) {
  refreshDetails('html5_est_produtos', {GRUPO: codigo});
}
</script>
</head><body>
<div class="painel">
  <div class="titulo">Nível 04</div>
  <div class="grade-wrap">
    <snk:query var="dados">
WITH grupos_exibicao AS (
    SELECT g3.codgrupoprod AS codgrupo, g3.descrgrupoprod AS descricao
      FROM tgfgru g3
     WHERE g3.grau = 3 AND g3.ativo = 'S' AND g3.codgrupoprod = :GRUPOPAI
    UNION ALL
    SELECT g4.codgrupoprod, g4.descrgrupoprod
      FROM tgfgru g4
     WHERE g4.grau = 4 AND g4.ativo = 'S' AND g4.codgrupai = :GRUPOPAI
),
produtos_filtrados AS (
    SELECT p.codprod, p.codgrupoprod, NVL(p.estmax,0) estmax
      FROM tgfpro p
     WHERE UPPER(NVL(:P_ATIVO,'T')) = 'T'
        OR (UPPER(:P_ATIVO) = 'A' AND p.ativo = 'S')
        OR (UPPER(:P_ATIVO) = 'I' AND p.ativo = 'N')
),
estoque AS (
    SELECT codprod, SUM(NVL(estoque,0)) estoqueatual
      FROM tgfest GROUP BY codprod
),
totais AS (
    SELECT p.codgrupoprod, SUM(p.estmax) estmax,
           SUM(NVL(e.estoqueatual,0)) estoqueatual
      FROM produtos_filtrados p
      LEFT JOIN estoque e ON e.codprod = p.codprod
     GROUP BY p.codgrupoprod
)
SELECT g.codgrupo, g.descricao,
       NVL(t.estmax,0) estmax, NVL(t.estoqueatual,0) estoqueatual,
       NVL(ROUND(t.estoqueatual / NULLIF(t.estmax,0) * 100,2),0) pct
  FROM grupos_exibicao g
  LEFT JOIN totais t ON t.codgrupoprod = g.codgrupo
 ORDER BY g.codgrupo 
    </snk:query>
    <table>
      <thead><tr><th>Descrição</th><th class="numero">Est. Máx.</th><th class="numero">Est. Atual</th><th class="numero">%</th></tr></thead>
      <tbody>
        <c:forEach items="${dados.rows}" var="row">
          <tr class="selecionavel" onclick="selecionar(${row.CODGRUPO})">
            <td><button class="selecao" type="button" onclick="event.stopPropagation(); selecionar(${row.CODGRUPO});"><c:out value="${row.DESCRICAO}"/></button></td>
            <td class="numero"><c:out value="${row.ESTMAX}"/></td>
            <td class="numero"><c:out value="${row.ESTOQUEATUAL}"/></td>
            <td class="percentual"><c:out value="${row.PCT}"/>%</td>
          </tr>
        </c:forEach>
        <c:if test="${empty dados.rows}"><tr><td colspan="4" class="vazio">Nenhum grupo encontrado para os filtros selecionados.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div>
</body></html>
